import React, { useState } from 'react';
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate
} from 'react-router-dom';
import { Container } from '@mui/material';
import Navbar from './components/Navbar';
import LoginForm from './components/LoginForm';
import SignupRequestForm from './components/SignupRequestForm';
import DocumentUploader from './components/DocumentUploader';
import AdminDashboard from './components/AdminDashboard';
import AdminUserDashboard from './components/AdminUserDashboard';
import ProtectedRoute from './components/ProtectedRoute';
import { AuthProvider } from './AuthContext';

function App() {
  const [loggedIn, setLoggedIn] = useState(false);

  return (
    <AuthProvider>
      <BrowserRouter future={{ v7_relativeSplatPath: true, v7_startTransition: true }}>
        <Navbar />
        <Container maxWidth="md" sx={{ mt: 4 }}>
          <Routes>
            <Route path="/" element={<LoginForm onLogin={() => setLoggedIn(true)} />} />
            <Route path="/signup" element={<SignupRequestForm />} />
            <Route path="/upload" element={<ProtectedRoute><DocumentUploader /></ProtectedRoute>} />
            <Route path="/admin" element={<ProtectedRoute><AdminDashboard /></ProtectedRoute>} />
            <Route path="/admin/users" element={<ProtectedRoute><AdminUserDashboard /></ProtectedRoute>} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </Container>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;