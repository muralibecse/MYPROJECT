import { useForm } from 'react-hook-form';
import { TextField, Button, Box } from '@mui/material';
import API from '../api';
import React from 'react';

export default function SignupRequestForm() {
  const { register, handleSubmit, reset } = useForm();

  const onSubmit = async (data: any) => {
    await API.post('/request-signup', new URLSearchParams(data));
    alert('Signup request sent!');
    reset();
  };

  return (
    <Box component="form" onSubmit={handleSubmit(onSubmit)} sx={{ mb: 4 }}>
      <h2>Request Access</h2>
      <TextField label="Email" fullWidth margin="normal" {...register('email')} />
      <TextField label="Reason" fullWidth multiline rows={4} margin="normal" {...register('reason')} />
      <Button type="submit" variant="contained">Submit</Button>
    </Box>
  );
}