from fastapi import APIRouter, Form, HTTPException
from fastapi.responses import JSONResponse

router = APIRouter()

# Simulated user store: email → {password, role}
users = {
    "admin@example.com": {"password": "admin123", "role": "admin"},
    "user1@example.com": {"password": "user123", "role": "user"}
}

# Pending signup requests
pending_requests = []

@router.post("/request-signup")
def request_signup(email: str = Form(...), reason: str = Form(...)):
    if email in users:
        raise HTTPException(status_code=400, detail="Email already registered")
    if any(req["email"] == email for req in pending_requests):
        raise HTTPException(status_code=400, detail="Signup request already pending")
    
    pending_requests.append({"email": email, "reason": reason})
    return {"message": "Signup request received"}

@router.get("/admin/pending-requests")
def get_pending_requests():
    return {"requests": pending_requests}

@router.post("/admin/create-user")
def create_user(email: str = Form(...), password: str = Form(...)):
    if email in users:
        raise HTTPException(status_code=400, detail="User already exists")

    # Remove from pending list
    global pending_requests
    pending_requests = [req for req in pending_requests if req["email"] != email]

    users[email] = {"password": password, "role": "user"}
    return {"message": f"User {email} created"}

@router.post("/login")
def login(email: str = Form(...), password: str = Form(...)):
    user = users.get(email)
    if user and user["password"] == password:
        return {
            "token": "mock-token",
            "role": user["role"]
        }
    raise HTTPException(status_code=401, detail="Invalid credentials")