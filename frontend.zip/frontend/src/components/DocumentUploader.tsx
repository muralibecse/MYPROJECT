import React, { useState, useEffect } from 'react';
import {
  TextField,
  Button,
  Box,
  Typography,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  LinearProgress,
  Autocomplete
} from '@mui/material';
import API from '../api';

export default function DocumentUploader() {
  const [applicationId, setApplicationId] = useState('');
  const [documentName, setDocumentName] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [overwritePrompt, setOverwritePrompt] = useState(false);
  const [existingFilename, setExistingFilename] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadComplete, setUploadComplete] = useState(false);
  const [availableDocs, setAvailableDocs] = useState<{ application_id: string; filename: string }[]>([]);
  const [selectedDoc, setSelectedDoc] = useState<{ application_id: string; filename: string } | null>(null);

  const token = localStorage.getItem('token');
  const role = localStorage.getItem('role');

  useEffect(() => {
    const fetchDocs = async () => {
      try {
        const res = await API.get('/list-documents');
        setAvailableDocs(res.data.documents);
      } catch (error) {
        console.error('Failed to fetch documents', error);
      }
    };
    fetchDocs();
  }, []);

  useEffect(() => {
    const fetchSelectedDocument = async () => {
      if (!selectedDoc) return;

      try {
        const res = await API.get(`/retrieve-document/${selectedDoc.application_id}`, {
          responseType: 'blob',
        });

        const blob = new Blob([res.data], { type: 'application/pdf' });
        const fetchedFile = new File([blob], selectedDoc.filename, { type: 'application/pdf' });
        setFile(fetchedFile);
        setApplicationId(selectedDoc.application_id);
      } catch (error) {
        alert('Failed to fetch selected document');
        console.error(error);
      }
    };

    fetchSelectedDocument();
  }, [selectedDoc]);

  const resetForm = () => {
    setApplicationId('');
    setDocumentName('');
    setFile(null);
    setUploadProgress(0);
    setUploadComplete(false);
    setSelectedDoc(null);
  };

  const handleUpload = async () => {
    if (!file) {
      alert('No document selected or uploaded');
      return;
    }

    if (!documentName.trim()) {
      alert('Please enter a document name');
      return;
    }

    const formData = new FormData();
    formData.append('document_name', documentName);
    formData.append('document', file);

    try {
      const res = await API.post('/process-document', formData, {
        onUploadProgress: (e) => {
          if (e.total !== undefined && e.total > 0) {
            const percent = Math.round((e.loaded * 100) / e.total);
            setUploadProgress(percent);
          } else {
            setUploadProgress(0);
          }
        }
      });

      if (res.data.overwrite_required) {
        setExistingFilename(res.data.filename);
        setApplicationId(res.data.application_id);
        setOverwritePrompt(true);
      } else {
        alert('Document processed successfully');
        setApplicationId(res.data.application_id);
        setUploadComplete(true);
        setUploadProgress(0);
        resetForm();
      }
    } catch (error) {
      alert('Processing failed');
      console.error(error);
    }
  };

  const handleOverwrite = async () => {
    const formData = new FormData();
    formData.append('application_id', applicationId);
    formData.append('document', file!);

    try {
      await API.post('/overwrite-document', formData);
      alert('Document overwritten successfully');
      setUploadComplete(true);
      resetForm();
    } catch (error) {
      alert('Overwrite failed');
      console.error(error);
    } finally {
      setOverwritePrompt(false);
      setUploadProgress(0);
    }
  };

  if (!token || role !== 'user') {
    return <Typography>Please log in as a user to process documents.</Typography>;
  }

  return (
    <Box sx={{ mt: 4 }}>
      <Typography variant="h5">Process Document</Typography>

      <TextField
        label="Application ID"
        fullWidth
        margin="normal"
        value={applicationId}
        InputProps={{ readOnly: true }}
      />

      <TextField
        label="Document Name"
        fullWidth
        margin="normal"
        value={documentName}
        onChange={(e) => setDocumentName(e.target.value)}
      />

      <Autocomplete
        options={availableDocs}
        getOptionLabel={(option) => option.filename}
        onChange={(event, value) => {
          setSelectedDoc(value);
        }}
        renderInput={(params) => (
          <TextField {...params} label="Search Document to Process" margin="normal" fullWidth />
        )}
      />

      {!selectedDoc && (
        <Button variant="outlined" component="label">
          Select PDF
          <input
            type="file"
            hidden
            accept="application/pdf"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
          />
        </Button>
      )}

      {file && (
        <Box sx={{ mt: 2 }}>
          <Typography variant="body2">
            <strong>Ready to process:</strong> {file.name} ({(file.size / 1024).toFixed(1)} KB)
          </Typography>
        </Box>
      )}

      {uploadProgress > 0 && (
        <Box sx={{ mt: 2 }}>
          <LinearProgress variant="determinate" value={uploadProgress} />
          <Typography variant="body2">{uploadProgress}%</Typography>
        </Box>
      )}

      <Box sx={{ mt: 2 }}>
        <Button variant="contained" onClick={handleUpload} disabled={!file}>
          Process the document
        </Button>
      </Box>

      <Dialog open={overwritePrompt} onClose={() => setOverwritePrompt(false)}>
        <DialogTitle>Overwrite Confirmation</DialogTitle>
        <DialogContent>
          A document named <strong>{existingFilename}</strong> already exists.
          Do you want to overwrite it?
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOverwritePrompt(false)}>Cancel</Button>
          <Button onClick={handleOverwrite} variant="contained" color="error">
            Overwrite
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}