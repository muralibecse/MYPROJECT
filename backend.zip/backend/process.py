from fastapi import APIRouter, UploadFile, File

router = APIRouter()

@router.post("/process-document")
async def process_document(document: UploadFile = File(...)):
    contents = await document.read()
    summary = f"Mock summary of {document.filename} ({len(contents)} bytes)"
    return {"summary": summary}