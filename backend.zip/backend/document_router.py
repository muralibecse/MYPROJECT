import os
import json
from datetime import datetime
from fastapi import APIRouter, Form, UploadFile, File, HTTPException, Request
from fastapi.responses import FileResponse

router = APIRouter()

# Load config
with open("config.json") as f:
    config = json.load(f)

STORAGE_PATH = config.get("storage_path", "./documents")
os.makedirs(STORAGE_PATH, exist_ok=True)

# Load logs
try:
    with open("logs.json") as f:
        action_log = json.load(f)
except FileNotFoundError:
    action_log = []

def log_action(action: str, application_id: str, filename: str):
    entry = {
        "timestamp": datetime.now().isoformat(),
        "action": action,
        "application_id": application_id,
        "filename": filename
    }
    action_log.append(entry)
    with open("logs.json", "w") as f:
        json.dump(action_log, f, indent=2)

@app.post("/process-document")
async def process_document(document: UploadFile = File(...)):
    if document.content_type != "application/pdf":
        raise HTTPException(status_code=400, detail="Only PDF files are allowed")

    # Peek at the next ID but don't commit yet
    application_id, next_id = get_next_application_id()
    target_path = os.path.join(STORAGE_PATH, f"{application_id}_{document.filename}")

    # Check if file already exists
    if os.path.exists(target_path):
        return {
            "message": "Document already exists",
            "overwrite_required": True,
            "filename": document.filename,
            "application_id": application_id
        }

    # Save file and commit counter
    with open(target_path, "wb") as f:
        f.write(await document.read())

    commit_application_id(next_id)  # ✅ Only commit after successful save
    log_action("upload", application_id, document.filename)

    return {
        "message": "Document saved",
        "application_id": application_id,
        "path": target_path
    }


@router.post("/overwrite-document")
async def overwrite_document(
    application_id: str = Form(...),
    document: UploadFile = File(...)
):
    target_path = os.path.join(STORAGE_PATH, f"{application_id}_{document.filename}")

    with open(target_path, "wb") as f:
        f.write(await document.read())

    log_action("overwrite", application_id, document.filename)
    return {"message": "Document overwritten", "path": target_path}

@router.get("/retrieve-document/{application_id}")
def retrieve_document(application_id: str):
    for filename in os.listdir(STORAGE_PATH):
        if filename.startswith(f"{application_id}_"):
            return FileResponse(
                path=os.path.join(STORAGE_PATH, filename),
                filename=filename,
                media_type="application/pdf"
            )
    raise HTTPException(status_code=404, detail="Document not found")

@router.get("/admin/logs")
def get_logs(request: Request):
    role = request.headers.get("X-User-Role")
    if role != "admin":
        raise HTTPException(status_code=403, detail="Access denied")
    return {"logs": action_log}