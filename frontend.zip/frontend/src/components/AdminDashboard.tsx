import { useEffect, useState } from 'react';
import API from '../api';
import React from 'react';

import {
  Typography,
  List,
  ListItem,
  ListItemText,
  Button,
  Divider,
  Box as MuiBox, // alias to avoid type conflicts
} from '@mui/material';

type SignupRequest = {
  email: string;
  reason: string;
};

export default function AdminDashboard() {
  const [requests, setRequests] = useState<SignupRequest[]>([]);

  useEffect(() => {
    // Replace with real API call
    setRequests([
      { email: 'KARTHICK@example.com', reason: 'Testing AI features' },
    ]);
  }, []);

  const approveUser = async (email: string) => {
    try {
      await API.post(
        '/admin/create-user',
        new URLSearchParams({ email, password: 'default123' })
      );
      alert(`User ${email} approved`);
      setRequests(prev => prev.filter(req => req.email !== email));
    } catch (error) {
      alert('Error approving user');
    }
  };

  return (
    <MuiBox sx={{ mt: 4 }}>
      <Typography variant="h5" gutterBottom>
        Pending Signup Requests
      </Typography>
      <List>
        {requests.map((req, idx) => (
          <MuiBox key={idx}>
            <ListItem
              secondaryAction={
                <Button
                  variant="contained"
                  onClick={() => approveUser(req.email)}
                >
                  Approve
                </Button>
              }
            >
              <ListItemText
                primary={req.email}
                secondary={`Reason: ${req.reason}`}
              />
            </ListItem>
            <Divider />
          </MuiBox>
        ))}
      </List>
    </MuiBox>
  );
}