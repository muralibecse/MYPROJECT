import React from 'react';
import { useForm } from 'react-hook-form';
import { TextField, Button, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import API from '../api';

type LoginFormProps = {
  onLogin: () => void;
};

export default function LoginForm({ onLogin }: LoginFormProps) {
  const { register, handleSubmit } = useForm();
  const navigate = useNavigate();

  const onSubmit = async (data: any) => {
    try {
      const res = await API.post('/login', new URLSearchParams(data));
      const { token, role } = res.data;

      // Store token and role
      localStorage.setItem('token', token);
      localStorage.setItem('role', role);

      // Trigger login state
      onLogin();

      // Navigate based on role
      if (role === 'admin') {
        navigate('/admin');
      } else {
        navigate('/upload');
      }
    } catch (error) {
      alert('Invalid credentials');
      console.error('Login error:', error);
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit(onSubmit)} sx={{ mb: 4 }}>
      <h2>Login</h2>
      <TextField
        label="Email"
        fullWidth
        margin="normal"
        {...register('email', { required: true })}
      />
      <TextField
        label="Password"
        type="password"
        fullWidth
        margin="normal"
        {...register('password', { required: true })}
      />
      <Button type="submit" variant="contained" fullWidth>
        Login
      </Button>
    </Box>
  );
}