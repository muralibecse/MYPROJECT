import React from 'react';
import { AppBar, Toolbar, Typography, Button } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';

export default function Navbar() {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');
  const role = localStorage.getItem('role');

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    navigate('/');
  };

  return (
    <AppBar position="static">
      <Toolbar>
        <Typography variant="h6" sx={{ flexGrow: 1 }}>
          Document Portal
        </Typography>

        {/* Always visible */}
        <Button color="inherit" component={Link} to="/">
          Login
        </Button>
        <Button color="inherit" component={Link} to="/signup">
          Signup
        </Button>

        {/* Visible only to authenticated users */}
        {token && role === 'user' && (
          <Button color="inherit" component={Link} to="/upload">
            Upload
          </Button>
        )}

        {token && role === 'admin' && (
          <Button color="inherit" component={Link} to="/admin">
            Admin Dashboard
          </Button>
        )}

        {token && (
          <Button color="inherit" onClick={handleLogout}>
            Logout
          </Button>
        )}
      </Toolbar>
    </AppBar>
  );
}