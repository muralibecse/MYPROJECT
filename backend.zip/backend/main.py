from fastapi import FastAPI, Form, HTTPException, UploadFile, File, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import os
import json
from datetime import datetime, timezone, timedelta

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load config
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")

with open(CONFIG_PATH) as f:
    config = json.load(f)

STORAGE_PATH = config.get("storage_path", "./documents")
ID_PREFIX = config.get("application_id_prefix", "APP-")
ID_START = config.get("application_id_start", 1000)

os.makedirs(STORAGE_PATH, exist_ok=True)

# File helpers
def load_json(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except FileNotFoundError:
        return default

def save_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

# User management
USERS_PATH = os.path.join(BASE_DIR, "users.json")
PENDING_PATH = os.path.join(BASE_DIR, "RequiredApprovalUsers.json")
COUNTER_PATH = os.path.join(BASE_DIR, "counter.json")
LOGS_PATH = os.path.join(BASE_DIR, "logs.json")

def load_users():
    return load_json(USERS_PATH, {})

def save_users(users):
    save_json(USERS_PATH, users)

def load_pending_requests():
    return load_json(PENDING_PATH, [])

def save_pending_requests(requests):
    save_json(PENDING_PATH, requests)

def get_next_application_id():
    counter = load_json(COUNTER_PATH, {"last_id": ID_START - 1})
    next_id = counter["last_id"] + 1
    return f"{ID_PREFIX}{next_id}", next_id

def commit_application_id(next_id: int):
    save_json(COUNTER_PATH, {"last_id": next_id})

action_log = load_json(LOGS_PATH, [])

def log_action(action: str, application_id: str, filename: str):
    entry = {
        "timestamp": datetime.now().isoformat(),
        "action": action,
        "application_id": application_id,
        "filename": filename
    }
    action_log.append(entry)
    save_json(LOGS_PATH, action_log)

# Routes
@app.post("/request-signup")
def request_signup(email: str = Form(...), reason: str = Form(...)):
    users = load_users()
    pending_requests = load_pending_requests()

    if email in users:
        raise HTTPException(status_code=400, detail="Email already registered")
    if any(req["email"] == email for req in pending_requests):
        raise HTTPException(status_code=400, detail="Signup request already pending")

    pending_requests.append({
        "email": email,
        "reason": reason,
        "requested_at": datetime.now(timezone.utc).isoformat()
    })
    save_pending_requests(pending_requests)

    return {"message": "Signup request received"}

@app.get("/admin/pending-requests")
def get_pending_requests():
    return {"requests": load_pending_requests()}

@app.post("/admin/create-user")
def create_user(email: str = Form(...), password: str = Form(...)):
    users = load_users()
    pending_requests = load_pending_requests()

    if email in users:
        raise HTTPException(status_code=400, detail="User already exists")

    updated_requests = [req for req in pending_requests if req["email"] != email]
    save_pending_requests(updated_requests)

    IST = timezone(timedelta(hours=5, minutes=30))
    approved_time = datetime.now(IST).isoformat()

    users[email] = {
        "password": password,
        "role": "user",
        "approved_at": approved_time
    }
    save_users(users)

    return {"message": f"User {email} created"}

@app.post("/login")
def login(email: str = Form(...), password: str = Form(...)):
    users = load_users()
    user = users.get(email)
    if user and user["password"] == password:
        return {
            "token": "mock-token",
            "role": user["role"]
        }
    raise HTTPException(status_code=401, detail="Invalid credentials")

@app.get("/admin/users")
def get_approved_users(request: Request):
    role = request.headers.get("X-User-Role")
    if role != "admin":
        raise HTTPException(status_code=403, detail="Access denied")
    return {"users": load_users()}

@app.post("/process-document")
async def process_document(
    document_name: str = Form(...),
    document: UploadFile = File(...)
):
    application_id, next_id = get_next_application_id()

    if document.content_type != "application/pdf":
        raise HTTPException(status_code=400, detail="Only PDF files are allowed")

    target_path = os.path.join(STORAGE_PATH, f"{application_id}_{document.filename}")

    if os.path.exists(target_path):
        return {
            "message": "Document already exists",
            "overwrite_required": True,
            "filename": document.filename,
            "application_id": application_id
        }

    with open(target_path, "wb") as f:
        f.write(await document.read())

    commit_application_id(next_id)
    log_action("upload", application_id, document.filename)

    meta_path = os.path.join(STORAGE_PATH, f"{application_id}_meta.json")
    with open(meta_path, "w") as f:
        json.dump({"document_name": document_name}, f)

    return {
        "message": "Document saved",
        "application_id": application_id,
        "document_name": document_name,
        "path": target_path
    }

@app.post("/overwrite-document")
async def overwrite_document(
    application_id: str = Form(...),
    document: UploadFile = File(...)
):
    target_path = os.path.join(STORAGE_PATH, f"{application_id}_{document.filename}")
    with open(target_path, "wb") as f:
        f.write(await document.read())
    log_action("overwrite", application_id, document.filename)
    return {"message": "Document overwritten", "path": target_path}

@app.get("/retrieve-document/{application_id}")
def retrieve_document(application_id: str):
    for filename in os.listdir(STORAGE_PATH):
        if filename.startswith(f"{application_id}_") and filename.endswith(".pdf"):
            return FileResponse(
                path=os.path.join(STORAGE_PATH, filename),
                filename=filename,
                media_type="application/pdf"
            )
    raise HTTPException(status_code=404, detail="Document not found")

@app.get("/admin/logs")
def get_logs(request: Request):
    role = request.headers.get("X-User-Role")
    if role != "admin":
        raise HTTPException(status_code=403, detail="Access denied")
    return {"logs": action_log}

@app.get("/list-documents")
def list_documents():
    files = []
    for filename in os.listdir(STORAGE_PATH):
        if filename.endswith(".pdf") and "_" in filename:
            application_id = filename.split("_")[0]
            files.append({
                "application_id": application_id,
                "filename": filename
            })
    return {"documents": files}

# Debugging support
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)