import React, { useEffect, useState } from 'react';
import {
  Typography,
  Box,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Paper,
  CircularProgress
} from '@mui/material';
import API from '../api';

export default function AdminUserDashboard() {
  const [users, setUsers] = useState<{ [email: string]: any }>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await API.get('/admin/users', {
          headers: {
            'X-User-Role': localStorage.getItem('role') || ''
          }
        });
        setUsers(res.data.users);
      } catch (error) {
        alert('Failed to load users');
        console.error(error);
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  return (
    <Box sx={{ mt: 4 }}>
      <Typography variant="h5" gutterBottom>
        Approved Users
      </Typography>

      {loading ? (
        <CircularProgress />
      ) : (
        <Paper elevation={3}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Email</TableCell>
                <TableCell>Role</TableCell>
                <TableCell>Approved At</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {Object.entries(users).map(([email, data]) => (
                <TableRow key={email}>
                  <TableCell>{email}</TableCell>
                  <TableCell>{data.role}</TableCell>
                  <TableCell>{data.approved_at || '—'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Paper>
      )}
    </Box>
  );
}