import React, { useState } from 'react';
import {
  TextField,
  Button,
  Box,
  Typography,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  LinearProgress
} from '@mui/material';
import API from '../api';

export default function DocumentProcessor() {
  const [applicationId, setApplicationId] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [overwritePrompt, setOverwritePrompt] = useState(false);
  const [existingFilename, setExistingFilename] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);

  const token = localStorage.getItem('token');
  const role = localStorage.getItem('role');

  if (!token) {
    return <Typography>Please log in to access document processing.</Typography>;
  }

  const handleProcess = async () => {
    if (!applicationId.trim()) {
      alert('Application ID is required');
      return;
    }

    if (!file) {
      alert('Please select a document');
      return;
    }

    if (file.type !== 'application/pdf') {
      alert('Only PDF files are allowed');
      return;
    }

    const formData = new FormData();
    formData.append('application_id', applicationId);
    formData.append('document', file);

    try {
      const res = await API.post('/process-document', formData, {
        onUploadProgress: (e) => {
          if (e.total !== undefined && e.total > 0) {
            const percent = Math.round((e.loaded * 100) / e.total);
            setUploadProgress(percent);
          } else {
            setUploadProgress(0);
          }
        }
      });

      if (res.data.overwrite_required) {
        setExistingFilename(res.data.filename);
        setOverwritePrompt(true);
      } else {
        alert('Document saved successfully');
        setUploadProgress(0);
      }
    } catch (error) {
      alert('Error processing document');
      console.error(error);
    }
  };

  const handleOverwrite = async () => {
    const formData = new FormData();
    formData.append('application_id', applicationId);
    formData.append('document', file!);

    try {
      await API.post('/overwrite-document', formData);
      alert('Document overwritten successfully');
    } catch (error) {
      alert('Error overwriting document');
      console.error(error);
    } finally {
      setOverwritePrompt(false);
      setUploadProgress(0);
    }
  };

  return (
    <Box sx={{ mt: 4 }}>
      <Typography variant="h5">Process Document</Typography>

      <TextField
        label="Application ID"
        fullWidth
        margin="normal"
        value={applicationId}
        onChange={(e) => setApplicationId(e.target.value)}
      />

      <Button variant="outlined" component="label">
        Upload PDF
        <input
          type="file"
          hidden
          accept="application/pdf"
          onChange={(e) => setFile(e.target.files?.[0] || null)}
        />
      </Button>

      {uploadProgress > 0 && (
        <Box sx={{ mt: 2 }}>
          <LinearProgress variant="determinate" value={uploadProgress} />
          <Typography variant="body2">{uploadProgress}%</Typography>
        </Box>
      )}

      <Box sx={{ mt: 2 }}>
        <Button variant="contained" onClick={handleProcess} sx={{ mr: 2 }}>
          Process
        </Button>
      </Box>

      <Dialog open={overwritePrompt} onClose={() => setOverwritePrompt(false)}>
        <DialogTitle>Overwrite Confirmation</DialogTitle>
        <DialogContent>
          A document named <strong>{existingFilename}</strong> already exists.
          Do you want to overwrite it?
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOverwritePrompt(false)}>Cancel</Button>
          <Button onClick={handleOverwrite} variant="contained" color="error">
            Overwrite
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}